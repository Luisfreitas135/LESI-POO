var searchData=
[
  ['verificacliente_0',['VerificaCliente',['../class_dados_1_1_gere_cliente.html#a507b447254f5167940ec48846166b061',1,'Dados::GereCliente']]],
  ['verificaimovel_1',['VerificaImovel',['../class_dados_1_1_gere_imovel.html#a95d9092e6ed8ebff9e10a313f00f2854',1,'Dados::GereImovel']]],
  ['verificarproprietario_2',['VerificarProprietario',['../class_dados_1_1_gere_proprietario.html#a363dda468b3cc1b92b68048307c39462',1,'Dados::GereProprietario']]]
];
