var searchData=
[
  ['proprietario_0',['Proprietario',['../class_objetos_negocios_1_1_proprietario.html',1,'ObjetosNegocios']]]
];
