var searchData=
[
  ['equals_0',['Equals',['../class_objetos_negocios_1_1_cliente.html#a39e8db78072a4ed0ae45c82c2413db41',1,'ObjetosNegocios.Cliente.Equals()'],['../class_objetos_negocios_1_1_contrato.html#a4209ec661c359c35261a3c265aea4953',1,'ObjetosNegocios.Contrato.Equals()'],['../class_objetos_negocios_1_1_imovel.html#aa15fd1db2d350576b175cf2fdca85718',1,'ObjetosNegocios.Imovel.Equals()'],['../class_objetos_negocios_1_1_proprietario.html#ae04df3730c065a780bcacd10758b92bc',1,'ObjetosNegocios.Proprietario.Equals()']]]
];
