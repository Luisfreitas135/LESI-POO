﻿/*
 *  Class morada
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
namespace ObjetosNegocios
{
    public class Morada
    {
        #region ATRIBUTOS

        private string rua;
        private int nPorta;
        private string codPostal;
        private string localidade;
   


        #endregion

        #region COMPORTAMENTO

        #region CONSTRUTORES
        public Morada()
        {

        }

        public Morada(string rua, int nPorta, string codPostal, string localidade)
        {
            this.rua = rua;
            this.nPorta = nPorta;
            this.codPostal = codPostal;
            this.localidade = localidade;   
        }

        #endregion
        #region PROPRIEDADES

        public string Rua
        {
            get { return rua; }
            set { rua = value; }
        }

        public int NPorta
        {
            get { return nPorta; }
            set { nPorta = value; }
        }

        public string CodPostal
        {
            get { return codPostal; }
            set { codPostal = value; }
        }

        public string Localidade
        {
            get { return localidade; }
            set { localidade = value; }
        }

        public string MoradaFinal
        {
            get { return "Rua: " + rua + " Numero de Porta: " + nPorta + " Codigo Postal: " + codPostal + " Localidade: " + localidade; }
        }
        #endregion
        #endregion
    }
}
