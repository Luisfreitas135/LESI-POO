﻿/*
 *  Class Cliente
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System;

namespace ObjetosNegocios
{
    [Serializable]
    public class Cliente : ICliente
    {
        #region ATRIBUTOS
        private string nome;
        private int contribuinteCliente;
        private int contactoCliente;
        private DateTime nascimento;
        #endregion

        #region COMPORTAMENTO
        #region CONSTRUTORES
        public Cliente () 
        {
           
            
        }

        public Cliente (string nome, int contribuinteCliente, DateTime nascimento,int contactoCliente)
        {
            this.nome = nome;
            this.contribuinteCliente = contribuinteCliente;
            this.nascimento = nascimento;
            this.contactoCliente = contactoCliente;
        }

        #endregion
        #region PROPRIEDADES
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }       
        public int ContribuinteCliente
        {
            get { return contribuinteCliente; }
            set { contribuinteCliente = value; }
        }
        public DateTime Nascimento
        { 
            get { return nascimento; } 
            set { nascimento = value; } 
        }
        public int ContactoCliente
        {
            get { return contactoCliente; }
            set { contactoCliente = value; }
        }
        #endregion

        #region OUTROS METODOS
        /// <summary>
        /// Vai compararar a propriedade contribuinteCliente de dois objetos Cliente para ver se são iguais.
        /// </summary>
        /// <param name="obj">Objeto</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj is Cliente other)
            {
                return contribuinteCliente == other.contribuinteCliente;
            }
            return false;
        }

        /// <summary>
        /// Vai retornar o código hash especifico da instância.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return contribuinteCliente.GetHashCode();
        }
        #endregion
        #endregion
    }
}
