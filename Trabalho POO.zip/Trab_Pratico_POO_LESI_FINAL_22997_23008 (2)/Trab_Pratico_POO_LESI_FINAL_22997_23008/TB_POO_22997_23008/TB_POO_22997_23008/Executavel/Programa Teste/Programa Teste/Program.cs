﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    public class Program
    {
        static void Main(string[] args)
        {   
            
            Regras.CarregaInformacao();
            //Adiciona um Cliente
            //Cria Cliente
            Cliente c = new Cliente();
            c.Nome = "Alberto Teixeira";
            c.ContribuinteCliente = 299699366;
            c.ContactoCliente = 253256259;
            c.Nascimento = new DateTime(2000, 2, 2);
            Console.WriteLine(Regras.InsereCliente(c));


            //Adiciona um Proprietario
            //Cria Proprietario
            Proprietario p = new Proprietario();
            p.NomeProp = "Carlos Moedas";
            p.ContribuinteProp = 277255266;
            p.ContactoProp = 251254257;
            p.Iban = "PT50000000000000000000000";
            Console.WriteLine(Regras.InsereProprietario(p));


            //Adiciona um Imovel e a sua Morada
            // Cria Imovel
            Imovel i = new Imovel();
            i.IdPredial = 231345;
            i.EstadoPredial = "Bom";
            i.ValorAluguer = 1500;
            i.ValorPredial = 120000;
            i.Proprietario = 277255266;
            //Cria Morada
            Morada m = new Morada();
            m.Rua = "Rua da Amizade";
            m.NPorta = 25;
            m.CodPostal = "4517-128";
            m.Localidade = "Lisboa";
            Console.WriteLine(Regras.InsereImovel(i, m));


            //Cria um Contrato
            //Contrato
            int contratoContribuinteCliente = 299699366;
            int contratoContribuinteProprietario = 277255266;
            int contratoIdImovel = 231345;
            //Cria Contrato
            Contrato con = new Contrato();
            con.ProprietarioC = contratoContribuinteProprietario;
            con.ContribuinteCCliente = contratoContribuinteCliente;
            con.IdcPredial = contratoIdImovel;
            Console.WriteLine(Regras.DadoContrato(con));


            //Pesquisar Cliente
            int pesquisarContribuinteCliente = 299699366;
            Console.WriteLine("Ficha do Cliente:" + Regras.PesquisarCliente(pesquisarContribuinteCliente));


            //Pesquisar Proprietario
            int pesquisarContribuinteProprietario = 277255266;
            Console.WriteLine("Ficha do proprietario:" + Regras.PesquisarProprietario(pesquisarContribuinteProprietario));


            //Pesquisar Imovel
            int pesquisarIdImovel = 231345;
            Console.WriteLine("Ficha do Imovel:" + Regras.PesquisarImovel(pesquisarIdImovel));


            //Pesquisar contratp
            int pesquisarNumeroContrato = 1;
            Console.WriteLine(Regras.PesquisarContrato(pesquisarNumeroContrato));

            Regras.GuardaInformacao();

            Console.ReadKey();

        }
    }
}
